# Production backend next step

The current web MVP intentionally uses localStorage for demo purposes.

For production:
1. Create a backend API.
2. Validate Telegram Mini App `initData` on the server.
3. Store users, tasks, claims, referrals and transactions in a database.
4. Make point issuance idempotent server-side.
5. Add rate limits and anti-abuse checks.
6. Never accept a client-supplied points balance as authoritative.
