# TaskMint Telegram Mini App — MVP

A starter MVP for a Telegram rewards/points Mini App.

## Included
- Telegram WebApp SDK integration
- Dark premium UI
- Home, Tasks, Invite, Rewards, Leaderboard, Profile
- Daily claim demo
- Referral-link generation
- Local demo state (no real-money withdrawals)

## Run locally
1. Serve `web/` over HTTP/HTTPS.
2. Open `web/index.html` in a browser for demo mode.
3. For Telegram Mini App testing, host the web folder on HTTPS and configure the BotFather Web App URL.

## Important
This MVP uses local browser storage for demonstration. Before production, replace demo state with a backend database and verify Telegram `initData` server-side. Do not treat client-side points as trusted.
